=== Woocommerce reply-to ===
Contributors: mahathun
Requires at least: 4.6
Stable tag: 4.6.1
Tags: woocommerce, reply-to-email, from email


== Description ==

This plugin will simply makes reply-to email address of a new order email notification, to the customer email address when submitting a new order using woocommere plugin.

== Installation ==




== ChangeLog ==

= 1.0 =
* First release.

== Upgrade Notice ==
